﻿using Microsoft.AspNetCore.Mvc;

namespace NASA_SpacE_App_ExpSpace
{
    // RepositoryController.cs
    public class RepositoryController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RepositoryController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var repositories = _context.Repositories.ToList();
            return View(repositories);
        }

        // Implement Create, Edit, Delete actions
    }

}
