﻿namespace NASA_SpacE_App_ExpSpace
{
    // Repository.cs
    public class Repository
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }

    // Branch.cs
    public class Branch
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int RepositoryId { get; set; }
        public Repository Repository { get; set; }
    }

}
